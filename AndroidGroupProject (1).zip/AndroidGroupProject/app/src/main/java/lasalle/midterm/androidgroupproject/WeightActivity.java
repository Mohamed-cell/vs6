package lasalle.midterm.androidgroupproject;

import androidx.appcompat.app.AppCompatActivity;

public class WeightActivity extends AppCompatActivity {
}

package lasalle.midterm.androidgroupproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class conversionOptions extends AppCompatActivity implements View.OnClickListener{

    //Variable declaration
    Button btnDistance, btnTime, btnTemperature, btnWeight, btnLogout;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Initialize();
    }

    //Method to initialize all variables with their correct ui button ids
    private void Initialize() {
        btnDistance =findViewById(R.id.btnDistance);
        btnTime  = findViewById(R.id.btnTime);
        btnTemperature = findViewById(R.id.btnTemperature);
        btnWeight = findViewById(R.id.btnWeight);
        btnLogout = findViewById(R.id.btnLogoutConversionPage);
    }

    @Override
    public void onClick(View view) {
        //Get the id of the button clicked
        int id = view.getId();

        //Switch case to get to different page based on what button is clicked
        switch (id){
            //if button clicked is btnDistance
            case R.id.btnDistance:
                Intent intentDistance = new Intent(this, DistanceActivity.class);
                startActivity(intentDistance);
                break;
            case R.id.btnTime:
                Intent intentTime = new Intent(this, TimeActivity.class);
                startActivity(intentTime);
                break;
            case R.id.btnTemperature:
                Intent intentTemperature = new Intent(this, TemperatureActivity.class);
                startActivity(intentTemperature);
                break;
            case R.id.btnWeight:
                Intent intentWeight = new Intent(this, WeightActivity.class);
                startActivity(intentWeight);
                break;
            case R.id.btnLogoutConversionPage:
                Intent intentConversionPageToLogout = new Intent(this, login.class);
                startActivity(intentConversionPageToLogout);
                break;
        }
    }
}

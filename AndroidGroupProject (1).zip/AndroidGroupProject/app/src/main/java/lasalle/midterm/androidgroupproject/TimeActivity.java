package lasalle.midterm.androidgroupproject;

import androidx.appcompat.app.AppCompatActivity;

public class TimeActivity extends AppCompatActivity {
}

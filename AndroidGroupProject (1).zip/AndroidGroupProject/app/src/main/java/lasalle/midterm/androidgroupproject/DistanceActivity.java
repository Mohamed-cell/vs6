package lasalle.midterm.androidgroupproject;

import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class DistanceActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    public void onClick(View view) {

    }
}
